<html>
<head>
<title>Hello world script</title>
</head>
<body>
<?php
echo "Hello world";
?>
</body>
</html>
