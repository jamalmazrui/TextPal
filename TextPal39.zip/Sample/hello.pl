print "Hello world";
