imports System
imports System.Windows.Forms

Module Program 
Sub Main() 
MessageBox.Show("Hello world")
End Sub
End Module


