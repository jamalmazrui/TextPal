require "Win32API"

module Win32
   class ClipboardError < StandardError; end
   class Clipboard
      VERSION = '0.4.0'
      
      # Clipboard data types
      TEXT        = 1
      OEMTEXT     = 7
      UNICODETEXT = 13
   		
      # Alloc constants
      GMEM_MOVEABLE = 0x0002
      GMEM_ZEROINIT = 0x0040
      GHND          = 0x0042
 
      # Clipboard specific functions
      @@OpenClipboard    = Win32API.new('user32', 'OpenClipboard', 'L', 'I')
      @@CloseClipboard   = Win32API.new('user32', 'CloseClipboard', 'V', 'I')
      @@GetClipboardData = Win32API.new('user32', 'GetClipboardData', 'I', 'P')
      @@SetClipboardData = Win32API.new('user32', 'SetClipboardData', 'II', 'I')
      @@EmptyClipboard   = Win32API.new('user32', 'EmptyClipboard', 'V', 'I')

      @@CountClipboardFormats = Win32API.new(
         'user32', 'CountClipboardFormats', 'V', 'I'
      )
      
      @@IsClipboardFormatAvailable = Win32API.new(
         'user32', 'IsClipboardFormatAvailable', 'I', 'I'
      )
      
      @@GetClipboardFormatName = Win32API.new(
         'user32', 'GetClipboardFormatName', 'IPI', 'I'
      )
      
      @@EnumClipboardFormats = Win32API.new(
         'user32', 'EnumClipboardFormats', 'I', 'I'
      )
      
      @@RegisterClipboardFormat = Win32API.new(
         'user32', 'RegisterClipboardFormat', 'P', 'I'
      )
   		
      # Generic Win32 functions
      @@GlobalAlloc  = Win32API.new('kernel32', 'GlobalAlloc', 'II' ,'I')
      @@GlobalLock   = Win32API.new('kernel32', 'GlobalLock', 'I' ,'I')
      @@GlobalFree   = Win32API.new('kernel32', 'GlobalFree', 'I' ,'I')
      @@Memcpy       = Win32API.new('msvcrt',  'memcpy', 'IPI', 'I')

      # Sets the clipboard contents to the data that you specify.  You may
      # optionally specify a clipboard format.  The default is Clipboard::TEXT.
      def self.set_data(clip_data, format = TEXT)
         self.open
         @@EmptyClipboard.call

         # NULL terminate text
         case format
            when TEXT, OEMTEXT, UNICODETEXT				
               clip_data << "\0"
         end

         # Global Allocate a movable piece of memory.
         hmem = @@GlobalAlloc.call(GHND, clip_data.length + 4)
         mem  = @@GlobalLock.call(hmem)
         @@Memcpy.call(mem, clip_data, clip_data.length)

         # Set the new data
         if @@SetClipboardData.call(format, hmem) == 0
            @@GlobalFree.call(hmem)
            self.close
            raise ClipboardError, "SetClipboardData() failed"
         end

         @@GlobalFree.call(hmem)   
         self.close
         self
      end 		

      # Returns the data currently in the clipboard.  If 'format' is
      # specified, it will attempt to retrieve the data in that format. The
      # default is Clipboard::TEXT. 		  		
      def self.data(format = TEXT)
         clipdata = ""
         self.open
         begin
            clipdata = @@GetClipboardData.call(format)
         rescue ArgumentError
            # Assume failure is caused by no data in clipboard
         end
         self.close
         clipdata
      end

      # An alias for Clipboard.data.
      def self.get_data(format = TEXT)
         self.data(format)
      end

      # Empties the contents of the clipboard.
      def self.empty
         self.open
         @@EmptyClipboard.call
         self.close
         self
      end

      # Returns the number of different data formats currently on the
      # clipboard.
      def self.num_formats
         count = 0
         self.open
         count = @@CountClipboardFormats.call
         self.close
         count
      end
      
      # Returns whether or not +format+ (an int) is currently available.
      def self.format_available?(format)
         @@IsClipboardFormatAvailable.call(format) == 0 ? false : true
      end
      
      # Returns the corresponding name for the given 'format_number', or nil
      # if it does not exist.  You cannot specify any of the predefined
      # clipboard formats (or nil is returned), only registered formats.
      def self.format_name(format)
         val = nil
         buf = 0.chr * 80
         self.open
         if @@GetClipboardFormatName.call(format, buf, buf.length) != 0
            val = buf
         end
         self.close
         val.split(0.chr).first rescue nil
      end
      
      # Returns a hash of all the current formats, with the format number as
      # the key and the format name as the value for that key.
      def self.formats
         formats = {}
         format = 0
         
         self.open
         while 0 != (format = @@EnumClipboardFormats.call(format))
            buf = 0.chr * 80
            @@GetClipboardFormatName.call(format, buf, buf.length)
            formats[format] = buf.split(0.chr).first
         end
         self.close
         formats
      end
      
      # Registers the given 'format' (a String) as a clipboard format, which
      # can then be used as a valid clipboard format.
      #
      # If a registered format with the specified name already exists, a new
      # format is not registered and the return value identifies the existing
      # format. This enables more than one application to copy and paste data
      # using the same registered clipboard format. Note that the format name
      # comparison is case-insensitive.
      #
      # Registered clipboard formats are identified by values in the range 0xC000
      # through 0xFFFF.
      def self.register_format(format)
         if @@RegisterClipboardFormat.call(format) == 0
            raise ClipboardError, "RegisterClipboardFormat() call failed"
         end
      end

      private

      def self.open
         if 0 == @@OpenClipboard.call(0)
            raise ClipboardError, "OpenClipboard() failed"
         end
      end

      def self.close
         @@CloseClipboard.call
      end
   end
end
